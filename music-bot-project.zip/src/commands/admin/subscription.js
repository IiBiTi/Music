/**
 * أمر إدارة الاشتراكات
 * يقوم بإدارة اشتراكات المستخدمين والسيرفرات
 */

const { EmbedBuilder } = require('discord.js');
const SubscriptionManager = require('../../utils/subscriptionManager');

module.exports = {
    name: 'subscription',
    aliases: ['sub', 'اشتراك'],
    description: 'إدارة اشتراكات البوتات',
    usage: '<prefix>subscription <add/info/extend/cancel/addbot/removebot> [معاملات إضافية]',
    category: 'admin',
    async execute(bot, message, args) {
        // التحقق من أن الأمر يتم تنفيذه في السيرفر الرئيسي للإدارة
        if (!message.guild) {
            return message.reply('هذا الأمر متاح فقط في السيرفرات.');
        }

        // التحقق من صلاحيات المستخدم
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply('ليس لديك صلاحيات كافية لاستخدام هذا الأمر!');
        }

        // التحقق من وجود معاملات
        if (!args.length) {
            return message.reply(`استخدام غير صحيح! الاستخدام الصحيح: \`${this.usage.replace('<prefix>', bot.options.prefix)}\``);
        }

        // إنشاء مدير الاشتراكات
        const subscriptionManager = new SubscriptionManager();

        // تحديد العملية
        const operation = args[0].toLowerCase();

        try {
            switch (operation) {
                case 'add':
                case 'إضافة':
                    await handleAddSubscription(message, args, subscriptionManager);
                    break;
                
                case 'info':
                case 'معلومات':
                    await handleSubscriptionInfo(message, args, subscriptionManager);
                    break;
                
                case 'extend':
                case 'تمديد':
                    await handleExtendSubscription(message, args, subscriptionManager);
                    break;
                
                case 'cancel':
                case 'إلغاء':
                    await handleCancelSubscription(message, args, subscriptionManager);
                    break;
                
                case 'addbot':
                case 'إضافة_بوت':
                    await handleAddBot(message, args, subscriptionManager);
                    break;
                
                case 'removebot':
                case 'إزالة_بوت':
                    await handleRemoveBot(message, args, subscriptionManager);
                    break;
                
                case 'plans':
                case 'خطط':
                    await handleListPlans(message, subscriptionManager);
                    break;
                
                default:
                    message.reply(`العملية غير صالحة. العمليات المتاحة: add, info, extend, cancel, addbot, removebot, plans`);
            }
        } catch (error) {
            console.error(error);
            message.reply(`❌ حدث خطأ: ${error.message}`);
        } finally {
            // إغلاق اتصال قاعدة البيانات
            subscriptionManager.close();
        }
    }
};

// معالجة إضافة اشتراك جديد
async function handleAddSubscription(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 3) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription add <معرف المستخدم> <نوع الخطة>`');
    }

    const userId = args[1];
    const planType = args[2].toLowerCase();

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // التحقق من وجود خطة الاشتراك
    const plan = subscriptionManager.getPlanByName(planType);
    if (!plan) {
        const plans = subscriptionManager.getAllPlans();
        let plansText = 'الخطط المتاحة:\n';
        plans.forEach(p => {
            plansText += `- ${p.name}: ${p.description} (${p.max_bots} بوت، ${p.duration_days} يوم، ${p.price}$)\n`;
        });
        return message.reply(`خطة الاشتراك "${planType}" غير موجودة.\n${plansText}`);
    }

    // إضافة الاشتراك
    const result = subscriptionManager.addSubscription(userId, message.guild.id, planType);

    if (result.success) {
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('تم إضافة الاشتراك بنجاح')
            .setDescription(result.message)
            .addFields(
                { name: 'المستخدم', value: `<@${userId}>`, inline: true },
                { name: 'الخطة', value: planType, inline: true },
                { name: 'عدد البوتات المسموح', value: `${plan.max_bots}`, inline: true },
                { name: 'المدة', value: `${plan.duration_days} يوم`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    } else {
        message.reply(`❌ ${result.message}`);
    }
}

// معالجة عرض معلومات الاشتراك
async function handleSubscriptionInfo(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 2) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription info <معرف المستخدم>`');
    }

    const userId = args[1];

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // الحصول على الاشتراك
    const subscription = subscriptionManager.getSubscription(userId, message.guild.id);

    if (!subscription) {
        return message.reply(`لا يوجد اشتراك للمستخدم <@${userId}> في هذا السيرفر.`);
    }

    // الحصول على معلومات الخطة
    const plan = subscriptionManager.getPlanByName(subscription.plan_type);
    
    // تحويل التواريخ
    const startDate = new Date(subscription.start_date * 1000).toLocaleDateString();
    const endDate = new Date(subscription.end_date * 1000).toLocaleDateString();
    
    // تحويل قائمة التوكنات
    const botTokens = JSON.parse(subscription.bot_tokens || '[]');
    
    // إنشاء رسالة المعلومات
    const embed = new EmbedBuilder()
        .setColor(subscription.is_active ? '#00FF00' : '#FF0000')
        .setTitle('معلومات الاشتراك')
        .setDescription(`معلومات اشتراك المستخدم <@${userId}> في هذا السيرفر.`)
        .addFields(
            { name: 'الحالة', value: subscription.is_active ? 'نشط' : 'غير نشط', inline: true },
            { name: 'الخطة', value: subscription.plan_type, inline: true },
            { name: 'تاريخ البدء', value: startDate, inline: true },
            { name: 'تاريخ الانتهاء', value: endDate, inline: true },
            { name: 'عدد البوتات المستخدمة', value: `${botTokens.length}/${plan.max_bots}`, inline: true }
        )
        .setTimestamp();

    // إضافة قائمة البوتات إذا وجدت
    if (botTokens.length > 0) {
        embed.addFields({ name: 'توكنات البوتات', value: botTokens.map((token, index) => `${index + 1}. ${token.substring(0, 10)}...`).join('\n') });
    }

    message.channel.send({ embeds: [embed] });
}

// معالجة تمديد الاشتراك
async function handleExtendSubscription(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 3) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription extend <معرف المستخدم> <عدد الأيام>`');
    }

    const userId = args[1];
    const durationDays = parseInt(args[2]);

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // التحقق من صحة عدد الأيام
    if (isNaN(durationDays) || durationDays <= 0) {
        return message.reply('عدد الأيام غير صالح. يجب أن يكون رقمًا موجبًا.');
    }

    // تمديد الاشتراك
    const result = subscriptionManager.extendSubscription(userId, message.guild.id, durationDays);

    if (result.success) {
        // الحصول على الاشتراك المحدث
        const subscription = subscriptionManager.getSubscription(userId, message.guild.id);
        const endDate = new Date(subscription.end_date * 1000).toLocaleDateString();

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('تم تمديد الاشتراك بنجاح')
            .setDescription(`تم تمديد اشتراك المستخدم <@${userId}> بنجاح.`)
            .addFields(
                { name: 'المدة المضافة', value: `${durationDays} يوم`, inline: true },
                { name: 'تاريخ الانتهاء الجديد', value: endDate, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    } else {
        message.reply(`❌ ${result.message}`);
    }
}

// معالجة إلغاء الاشتراك
async function handleCancelSubscription(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 2) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription cancel <معرف المستخدم>`');
    }

    const userId = args[1];

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // إلغاء الاشتراك
    const result = subscriptionManager.cancelSubscription(userId, message.guild.id);

    if (result.success) {
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('تم إلغاء الاشتراك بنجاح')
            .setDescription(`تم إلغاء اشتراك المستخدم <@${userId}> بنجاح.`)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    } else {
        message.reply(`❌ ${result.message}`);
    }
}

// معالجة إضافة بوت إلى الاشتراك
async function handleAddBot(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 3) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription addbot <معرف المستخدم> <توكن البوت>`');
    }

    const userId = args[1];
    const botToken = args[2];

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // إضافة البوت
    const result = subscriptionManager.addBotToken(userId, message.guild.id, botToken);

    if (result.success) {
        // الحصول على الاشتراك المحدث
        const subscription = subscriptionManager.getSubscription(userId, message.guild.id);
        const plan = subscriptionManager.getPlanByName(subscription.plan_type);
        const botTokens = JSON.parse(subscription.bot_tokens || '[]');

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('تم إضافة البوت بنجاح')
            .setDescription(`تم إضافة البوت إلى اشتراك المستخدم <@${userId}> بنجاح.`)
            .addFields(
                { name: 'عدد البوتات المستخدمة', value: `${botTokens.length}/${plan.max_bots}`, inline: true },
                { name: 'توكن البوت', value: `${botToken.substring(0, 10)}...`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    } else {
        message.reply(`❌ ${result.message}`);
    }
}

// معالجة إزالة بوت من الاشتراك
async function handleRemoveBot(message, args, subscriptionManager) {
    // التحقق من وجود المعاملات المطلوبة
    if (args.length < 3) {
        return message.reply('استخدام غير صحيح! الاستخدام الصحيح: `subscription removebot <معرف المستخدم> <توكن البوت>`');
    }

    const userId = args[1];
    const botToken = args[2];

    // التحقق من صحة معرف المستخدم
    if (!/^\d+$/.test(userId)) {
        return message.reply('معرف المستخدم غير صالح. يجب أن يكون رقمًا.');
    }

    // إزالة البوت
    const result = subscriptionManager.removeBotToken(userId, message.guild.id, botToken);

    if (result.success) {
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('تم إزالة البوت بنجاح')
            .setDescription(`تم إزالة البوت من اشتراك المستخدم <@${userId}> بنجاح.`)
            .addFields(
                { name: 'توكن البوت', value: `${botToken.substring(0, 10)}...`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    } else {
        message.reply(`❌ ${result.message}`);
    }
}

// معالجة عرض خطط الاشتراك
async function handleListPlans(message, subscriptionManager) {
    // الحصول على جميع الخطط
    const plans = subscriptionManager.getAllPlans();

    if (plans.length === 0) {
        return message.reply('لا توجد خطط اشتراك متاحة حاليًا.');
    }

    // إنشاء رسالة الخطط
    const embed = new EmbedBuilder()
        .setColor('#0099FF')
        .setTitle('خطط الاشتراك المتاحة')
        .setDescription('قائمة بجميع خطط الاشتراك المتاحة حاليًا.')
        .setTimestamp();

    // إضافة كل خطة
    plans.forEach(plan => {
        const features = JSON.parse(plan.features || '[]');
        
        embed.addFields({
            name: `${plan.name} - ${plan.price}$`,
            value: `${plan.description}\n**المدة:** ${plan.duration_days} يوم\n**عدد البوتات:** ${plan.max_bots}\n**الميزات:** ${features.join(', ')}`
        });
    });

    message.channel.send({ embeds: [embed] });
}
