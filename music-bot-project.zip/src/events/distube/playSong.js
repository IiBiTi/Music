/**
 * حدث تشغيل الأغنية
 * يتم تنفيذه عند بدء تشغيل أغنية جديدة
 */

module.exports = (bot, queue, song) => {
    // إنشاء رسالة الإشعار
    let playMessage = `🎵 **بدأ التشغيل:** [${song.name}](${song.url})`;
    
    // إضافة معلومات إضافية
    playMessage += `\n⏱️ **المدة:** \`${song.formattedDuration}\``;
    playMessage += `\n👤 **بواسطة:** ${song.user}`;
    playMessage += `\n🔊 **مستوى الصوت:** ${queue.volume}%`;
    playMessage += `\n🎧 **المنصة:** ${bot.currentPlatform}`;
    
    // إرسال الرسالة
    if (bot.options.embedEnabled) {
        const { EmbedBuilder } = require('discord.js');
        const embed = new EmbedBuilder()
            .setColor(bot.options.embedColor)
            .setTitle('بدأ التشغيل')
            .setDescription(playMessage)
            .setThumbnail(song.thumbnail)
            .setTimestamp();
        
        // إضافة أزرار التحكم إذا كانت مفعلة
        if (bot.options.buttonsEnabled) {
            const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('pause')
                        .setLabel('إيقاف مؤقت')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('⏸️'),
                    new ButtonBuilder()
                        .setCustomId('skip')
                        .setLabel('تخطي')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('⏭️'),
                    new ButtonBuilder()
                        .setCustomId('stop')
                        .setLabel('إيقاف')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('⏹️'),
                    new ButtonBuilder()
                        .setCustomId('queue')
                        .setLabel('القائمة')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('📜')
                );
            
            queue.textChannel.send({ embeds: [embed], components: [row] });
        } else {
            queue.textChannel.send({ embeds: [embed] });
        }
    } else {
        queue.textChannel.send(playMessage);
    }
};
