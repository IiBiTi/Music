/**
 * ملف البوت الرئيسي لمشروع بوت الميوزك متعدد البوتات
 */

// استيراد المكتبات اللازمة
const { Client, GatewayIntentBits, Collection, Events } = require('discord.js');
const { DisTube } = require('distube');
const { SpotifyPlugin } = require('@distube/spotify');
const { SoundCloudPlugin } = require('@distube/soundcloud');
const { YtDlpPlugin } = require('@distube/yt-dlp');
const fs = require('fs');
const path = require('path');
const config = require('../config/config');

// إنشاء فئة البوت الأساسية
class MusicBot {
    constructor(token, options = {}) {
        // دمج الإعدادات الافتراضية مع الإعدادات المخصصة
        this.options = {
            ...config.defaultSettings,
            ...options
        };

        // إنشاء عميل Discord
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.MessageContent
            ]
        });

        // تعيين التوكن
        this.token = token;

        // إنشاء مجموعات للأوامر والأحداث
        this.commands = new Collection();
        this.aliases = new Collection();

        // إنشاء كائن DisTube
        this.distube = new DisTube(this.client, {
            leaveOnStop: false,
            leaveOnEmpty: true,
            leaveOnFinish: false,
            emitNewSongOnly: true,
            emitAddSongWhenCreatingQueue: false,
            emitAddListWhenCreatingQueue: false,
            plugins: this.setupPlugins()
        });

        // تعيين المنصة الحالية
        this.currentPlatform = this.options.defaultPlatform;
    }

    // إعداد إضافات DisTube
    setupPlugins() {
        const plugins = [];
        
        if (config.platforms.youtube.enabled) {
            plugins.push(new YtDlpPlugin());
        }
        
        if (config.platforms.spotify.enabled) {
            plugins.push(new SpotifyPlugin({
                emitEventsAfterFetching: true,
                api: {
                    clientId: config.platforms.spotify.clientId,
                    clientSecret: config.platforms.spotify.clientSecret,
                }
            }));
        }
        
        if (config.platforms.soundcloud.enabled) {
            plugins.push(new SoundCloudPlugin());
        }
        
        return plugins;
    }

    // تحميل الأوامر
    loadCommands() {
        const commandsPath = path.join(__dirname, 'commands');
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            const command = require(filePath);
            
            // تسجيل الأمر في مجموعة الأوامر
            if ('name' in command && 'execute' in command) {
                this.commands.set(command.name, command);
                
                // تسجيل الاختصارات إذا وجدت
                if (command.aliases && Array.isArray(command.aliases)) {
                    command.aliases.forEach(alias => {
                        this.aliases.set(alias, command.name);
                    });
                }
            }
        }
        
        console.log(`تم تحميل ${this.commands.size} أمر.`);
        return this;
    }

    // تحميل الأحداث
    loadEvents() {
        const eventsPath = path.join(__dirname, 'events');
        const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

        for (const file of eventFiles) {
            const filePath = path.join(eventsPath, file);
            const event = require(filePath);
            
            if (event.once) {
                this.client.once(event.name, (...args) => event.execute(this, ...args));
            } else {
                this.client.on(event.name, (...args) => event.execute(this, ...args));
            }
        }
        
        console.log(`تم تحميل أحداث Discord.`);
        
        // تحميل أحداث DisTube
        this.setupDistubeEvents();
        
        return this;
    }

    // إعداد أحداث DisTube
    setupDistubeEvents() {
        const distubeEvents = [
            'playSong',
            'addSong',
            'addList',
            'error',
            'finish',
            'noRelated',
            'empty',
            'searchNoResult',
            'searchResult',
            'searchCancel',
            'searchInvalidAnswer',
            'searchDone',
            'disconnect'
        ];

        for (const event of distubeEvents) {
            const eventPath = path.join(__dirname, 'events', 'distube', `${event}.js`);
            
            if (fs.existsSync(eventPath)) {
                const eventHandler = require(eventPath);
                this.distube.on(event, (...args) => eventHandler(this, ...args));
            } else {
                // إنشاء معالج افتراضي للأحداث غير المعرفة
                this.distube.on(event, (...args) => {
                    if (config.logging.enabled && config.logging.level === 'debug') {
                        console.log(`[DisTube] حدث ${event}:`, args);
                    }
                });
            }
        }
        
        console.log(`تم تحميل أحداث DisTube.`);
        return this;
    }

    // تغيير المنصة
    switchPlatform(platform) {
        if (config.platforms[platform] && config.platforms[platform].enabled) {
            this.currentPlatform = platform;
            return true;
        }
        return false;
    }

    // تشغيل البوت
    start() {
        // تسجيل معالج الرسائل
        this.client.on(Events.MessageCreate, async message => {
            // تجاهل الرسائل من البوتات
            if (message.author.bot) return;
            
            // التحقق من البادئة
            if (!message.content.startsWith(this.options.prefix)) return;
            
            // استخراج الأمر والمعاملات
            const args = message.content.slice(this.options.prefix.length).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();
            
            // البحث عن الأمر
            const command = this.commands.get(commandName) || this.commands.get(this.aliases.get(commandName));
            
            // إذا لم يتم العثور على الأمر
            if (!command) return;
            
            // التحقق من الحظر
            if (config.permissions.blacklistedUsers.includes(message.author.id)) {
                return message.reply('أنت محظور من استخدام هذا البوت.');
            }
            
            // تنفيذ الأمر
            try {
                command.execute(this, message, args);
            } catch (error) {
                console.error(error);
                message.reply('حدث خطأ أثناء تنفيذ الأمر!');
            }
        });

        // تسجيل الدخول إلى Discord
        this.client.login(this.token)
            .then(() => {
                console.log(`تم تسجيل الدخول كـ ${this.client.user.tag}`);
            })
            .catch(error => {
                console.error('فشل تسجيل الدخول:', error);
            });
            
        return this;
    }
}

// إنشاء فئة مدير البوتات المتعددة
class BotManager {
    constructor() {
        this.bots = new Map();
    }
    
    // إنشاء بوت جديد
    createBot(token, options = {}) {
        const bot = new MusicBot(token, options);
        this.bots.set(token, bot);
        return bot;
    }
    
    // الحصول على بوت بواسطة التوكن
    getBot(token) {
        return this.bots.get(token);
    }
    
    // الحصول على جميع البوتات
    getAllBots() {
        return Array.from(this.bots.values());
    }
    
    // إزالة بوت
    removeBot(token) {
        const bot = this.bots.get(token);
        if (bot) {
            // إيقاف البوت
            bot.client.destroy();
            this.bots.delete(token);
            return true;
        }
        return false;
    }
    
    // تحديث إعدادات جميع البوتات
    updateAllBotsSettings(settings) {
        for (const bot of this.bots.values()) {
            bot.options = {
                ...bot.options,
                ...settings
            };
        }
    }
    
    // تغيير المنصة لجميع البوتات
    switchPlatformForAllBots(platform) {
        let success = true;
        for (const bot of this.bots.values()) {
            if (!bot.switchPlatform(platform)) {
                success = false;
            }
        }
        return success;
    }
}

// تصدير الفئات
module.exports = {
    MusicBot,
    BotManager
};
