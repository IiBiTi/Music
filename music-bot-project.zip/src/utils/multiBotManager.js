/**
 * نظام إدارة البوتات المتعددة
 * هذا الملف يوفر واجهة للتحكم في البوتات المتعددة
 */

const { MusicBot } = require('../index');
const config = require('../../config/config');
const fs = require('fs');
const path = require('path');

class MultiBotManager {
    constructor() {
        this.bots = new Map();
        this.botsConfig = new Map();
        this.configPath = path.join(__dirname, '../../config/bots.json');
        
        // تحميل تكوينات البوتات إذا كانت موجودة
        this.loadBotsConfig();
    }

    // تحميل تكوينات البوتات
    loadBotsConfig() {
        try {
            if (fs.existsSync(this.configPath)) {
                const botsData = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
                
                for (const [token, botConfig] of Object.entries(botsData)) {
                    this.botsConfig.set(token, botConfig);
                }
                
                console.log(`تم تحميل تكوينات ${this.botsConfig.size} بوت.`);
            } else {
                // إنشاء ملف تكوين فارغ إذا لم يكن موجودًا
                fs.writeFileSync(this.configPath, JSON.stringify({}, null, 2));
                console.log('تم إنشاء ملف تكوين البوتات.');
            }
        } catch (error) {
            console.error('فشل تحميل تكوينات البوتات:', error);
        }
    }

    // حفظ تكوينات البوتات
    saveBotsConfig() {
        try {
            const botsData = {};
            
            for (const [token, botConfig] of this.botsConfig.entries()) {
                botsData[token] = botConfig;
            }
            
            fs.writeFileSync(this.configPath, JSON.stringify(botsData, null, 2));
            console.log('تم حفظ تكوينات البوتات.');
        } catch (error) {
            console.error('فشل حفظ تكوينات البوتات:', error);
        }
    }

    // إنشاء بوت جديد
    createBot(token, options = {}) {
        // التحقق من عدم تجاوز الحد الأقصى للبوتات
        if (this.bots.size >= config.multiBot.maxBots) {
            throw new Error(`تم الوصول إلى الحد الأقصى للبوتات (${config.multiBot.maxBots}).`);
        }
        
        // التحقق من عدم وجود البوت بالفعل
        if (this.bots.has(token)) {
            throw new Error('البوت موجود بالفعل.');
        }
        
        try {
            // دمج الإعدادات الافتراضية مع الإعدادات المخصصة
            const botConfig = {
                ...config.defaultSettings,
                ...options
            };
            
            // إنشاء البوت
            const bot = new MusicBot(token, botConfig);
            
            // تحميل الأوامر والأحداث
            bot.loadCommands().loadEvents();
            
            // تشغيل البوت
            bot.start();
            
            // إضافة البوت إلى القائمة
            this.bots.set(token, bot);
            
            // حفظ تكوين البوت
            this.botsConfig.set(token, botConfig);
            this.saveBotsConfig();
            
            return bot;
        } catch (error) {
            console.error('فشل إنشاء البوت:', error);
            throw error;
        }
    }

    // الحصول على بوت بواسطة التوكن
    getBot(token) {
        return this.bots.get(token);
    }

    // الحصول على جميع البوتات
    getAllBots() {
        return Array.from(this.bots.values());
    }

    // الحصول على قائمة توكنات البوتات
    getBotTokens() {
        return Array.from(this.bots.keys());
    }

    // إيقاف وإزالة بوت
    removeBot(token) {
        const bot = this.bots.get(token);
        if (bot) {
            // إيقاف البوت
            bot.client.destroy();
            
            // إزالة البوت من القائمة
            this.bots.delete(token);
            
            // إزالة تكوين البوت
            this.botsConfig.delete(token);
            this.saveBotsConfig();
            
            return true;
        }
        return false;
    }

    // تحديث إعدادات بوت معين
    updateBotSettings(token, settings) {
        const bot = this.bots.get(token);
        if (bot) {
            // تحديث إعدادات البوت
            bot.options = {
                ...bot.options,
                ...settings
            };
            
            // تحديث تكوين البوت
            this.botsConfig.set(token, bot.options);
            this.saveBotsConfig();
            
            return true;
        }
        return false;
    }

    // تحديث إعدادات جميع البوتات
    updateAllBotsSettings(settings) {
        for (const [token, bot] of this.bots.entries()) {
            // تحديث إعدادات البوت
            bot.options = {
                ...bot.options,
                ...settings
            };
            
            // تحديث تكوين البوت
            this.botsConfig.set(token, bot.options);
        }
        
        // حفظ التكوينات
        this.saveBotsConfig();
        
        return true;
    }

    // تغيير المنصة لبوت معين
    switchPlatform(token, platform) {
        const bot = this.bots.get(token);
        if (bot) {
            return bot.switchPlatform(platform);
        }
        return false;
    }

    // تغيير المنصة لجميع البوتات
    switchPlatformForAllBots(platform) {
        let success = true;
        for (const bot of this.bots.values()) {
            if (!bot.switchPlatform(platform)) {
                success = false;
            }
        }
        return success;
    }

    // تغيير اسم بوت معين
    changeBotUsername(token, username) {
        const bot = this.bots.get(token);
        if (bot) {
            return bot.client.user.setUsername(username)
                .then(() => true)
                .catch(error => {
                    console.error('فشل تغيير اسم البوت:', error);
                    return false;
                });
        }
        return false;
    }

    // تغيير صورة بوت معين
    changeBotAvatar(token, avatarURL) {
        const bot = this.bots.get(token);
        if (bot) {
            return bot.client.user.setAvatar(avatarURL)
                .then(() => true)
                .catch(error => {
                    console.error('فشل تغيير صورة البوت:', error);
                    return false;
                });
        }
        return false;
    }

    // تغيير اسم جميع البوتات
    changeAllBotsUsername(username) {
        const promises = [];
        for (const bot of this.bots.values()) {
            promises.push(
                bot.client.user.setUsername(username)
                    .catch(error => {
                        console.error('فشل تغيير اسم البوت:', error);
                        return false;
                    })
            );
        }
        
        return Promise.all(promises)
            .then(results => !results.includes(false))
            .catch(() => false);
    }

    // تغيير صورة جميع البوتات
    changeAllBotsAvatar(avatarURL) {
        const promises = [];
        for (const bot of this.bots.values()) {
            promises.push(
                bot.client.user.setAvatar(avatarURL)
                    .catch(error => {
                        console.error('فشل تغيير صورة البوت:', error);
                        return false;
                    })
            );
        }
        
        return Promise.all(promises)
            .then(results => !results.includes(false))
            .catch(() => false);
    }

    // تفعيل/تعطيل نظام الأزرار لبوت معين
    toggleButtons(token, enabled) {
        return this.updateBotSettings(token, { buttonsEnabled: enabled });
    }

    // تفعيل/تعطيل نظام الأزرار لجميع البوتات
    toggleButtonsForAllBots(enabled) {
        return this.updateAllBotsSettings({ buttonsEnabled: enabled });
    }

    // تفعيل/تعطيل نظام الإمبيد لبوت معين
    toggleEmbed(token, enabled) {
        return this.updateBotSettings(token, { embedEnabled: enabled });
    }

    // تفعيل/تعطيل نظام الإمبيد لجميع البوتات
    toggleEmbedForAllBots(enabled) {
        return this.updateAllBotsSettings({ embedEnabled: enabled });
    }

    // إضافة مستخدم إلى القائمة السوداء
    addUserToBlacklist(userId) {
        if (!config.permissions.blacklistedUsers.includes(userId)) {
            config.permissions.blacklistedUsers.push(userId);
            return true;
        }
        return false;
    }

    // إزالة مستخدم من القائمة السوداء
    removeUserFromBlacklist(userId) {
        const index = config.permissions.blacklistedUsers.indexOf(userId);
        if (index !== -1) {
            config.permissions.blacklistedUsers.splice(index, 1);
            return true;
        }
        return false;
    }

    // الحصول على قائمة المستخدمين المحظورين
    getBlacklistedUsers() {
        return [...config.permissions.blacklistedUsers];
    }
}

module.exports = MultiBotManager;
